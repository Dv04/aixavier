'use client';

import { motion } from "framer-motion";

// HUD intentionally disabled for main site to maintain calm visuals.
export default function HUD() {
  return null;
}
