#!/usr/bin/env python3
"""Generate a short demo video for synthetic RTSP server."""
from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np

OUTPUT = Path(__file__).resolve().parent / "demo_stream.mp4"


def main() -> None:
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    fps = 25
    duration_sec = 10
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(str(OUTPUT), fourcc, fps, (640, 360))
    for i in range(fps * duration_sec):
        frame = np.zeros((360, 640, 3), dtype=np.uint8)
        color = ((i * 3) % 255, (i * 7) % 255, (i * 11) % 255)
        cv2.rectangle(frame, (50, 50), (590, 310), color, thickness=-1)
        cv2.putText(frame, f"Frame {i}", (80, 180), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 2)
        writer.write(frame)
    writer.release()


if __name__ == "__main__":
    main()
