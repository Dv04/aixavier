# Demo Data

- `generate_demo.py` creates a synthetic 10-second MP4 at `demo_stream.mp4` (auto-run by `make demo`).
- `Dockerfile` builds a helper container that regenerates the clip when needed.
- Public datasets for production are catalogued in `docs/datasets.md` (auto-managed by agent).
